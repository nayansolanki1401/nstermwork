import java.util.*;
public class CaesarCipher {
    public static String encrypt(String input) {
        StringBuilder cipher = new StringBuilder();

        for (int i = 0; i < input.length(); i++) {
            if (input.charAt(i) == '$') {
                cipher.append("$");
                continue;
            } else if ((int) input.charAt(i) >= 65 && (int) input.charAt(i) <= 91) {
                if ((int) input.charAt(i) + 3 > 90) {
                    int temp = (int) input.charAt(i) + 3 - 90;
                    cipher.append((char)(64 + temp));
                } else
                    cipher.append((char)((int) input.charAt(i) + 3));
            } else {
                if ((int) input.charAt(i) + 3 > 122) {
                    int temp = (int) input.charAt(i) + 3 - 122;
                    cipher.append((char)(96 + temp));
                } else
                    cipher.append((char)((int) input.charAt(i) + 3));
            }
        }

        return cipher + "";
    }

    public static String decrypt(String cipher) {
        StringBuilder msg = new StringBuilder();

        for (int i = 0; i < cipher.length(); i++) {
            if (cipher.charAt(i) == '$') {
                msg.append("$");
                continue;
            } else if ((int) cipher.charAt(i) >= 65 && (int) cipher.charAt(i) <= 91) {
                if ((int) cipher.charAt(i) - 3 < 65) {
                    int temp = 65 - ((int) cipher.charAt(i) - 3);
                    msg.append((char)(91 - temp));
                } else
                    msg.append((char)((int) cipher.charAt(i) - 3));
            } else {
                if ((int) cipher.charAt(i) - 3 < 97) {
                    int temp = 97 - ((int) cipher.charAt(i) - 3);
                    msg.append((char)(123 - temp));
                } else
                    msg.append((char)((int) cipher.charAt(i) - 3));
            }
        }

        return msg + "";
    }

    public static void main(String args[]) {
        Scanner scan = new Scanner(System.in);
        System.out.println("Enter Message: ");
        String input = scan.nextLine().replace(" ", "$");

        String cipher = encrypt(input);
        System.out.println("Encrypted Message: " + cipher);

        String msg = decrypt(cipher);
        System.out.println("Decrypted Message: " + msg.replace("$", " "));
    }
}