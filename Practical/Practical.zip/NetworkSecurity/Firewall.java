import java.util.*;
import java.io.*;
import java.net.*;
public class Firewall {
    public static void main(String args[]) throws IOException {
        ServerSocket ss = new ServerSocket(4444);
        Socket server1 = new Socket("127.0.0.1", 1234);
        Socket server2 = new Socket("127.0.0.1", 3456);
        Socket con = ss.accept();

        DataInputStream input = new DataInputStream(con.getInputStream());
        DataOutputStream dos1 = new DataOutputStream(server1.getOutputStream());
        DataOutputStream dos2 = new DataOutputStream(server2.getOutputStream());
        System.out.println("Firewall Running...");
        while (true) {
            String msg = input.readUTF();
            System.out.println(msg);

            if (msg.equalsIgnoreCase("exit")) {
                System.out.println("Ending Firewall...");
                dos1.writeUTF(msg);
                dos2.writeUTF(msg);
                break;
            } else {
                int serverno = checkMsg(msg);
                System.out.println(serverno);
                if (serverno == 1234)
                    dos1.writeUTF(msg);
                else
                    dos2.writeUTF(msg);
            }
        }
    }
    public static int checkMsg(String str) throws IOException {
        BufferedReader br = new BufferedReader(new FileReader("keywords.txt"));
        String temp = "";
        while ((temp = br.readLine()) != null) {
            if ((str.toUpperCase()).contains(temp.toUpperCase())) {
                return 1234;
            }
        }
        return 3456;
    }
}