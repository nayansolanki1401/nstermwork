import java.io.*;
import java.net.*;
public class Firewall3 {
    public static void main(String args[]) {
        try {
            System.out.println("Firewall Started...");
            ServerSocket ss = new ServerSocket(1234);
            Socket con = ss.accept();

            DataInputStream input = new DataInputStream(con.getInputStream());
            String msg = input.readUTF();

            Socket fs = new Socket("127.0.0.1", 3456);
            DataOutputStream dos = new DataOutputStream(fs.getOutputStream());

            if (checkString(msg) == null) {
                dos.writeBytes(msg);
                System.out.println("String successfully sent as it is valid: " + msg);
            } else {
                System.out.println("String " + msg + " Not Sent!");
                System.out.println("Illegal Word is used in the String to be sended: " + checkString(msg));
            }
        } catch (Exception e) {
            System.out.println("Something went wrong: " + e);
        }
    }



    public static String checkString(String s) throws IOException {
        BufferedReader br = new BufferedReader(new FileReader("keywords.txt"));
        String temp = "";
        while ((temp = br.readLine()) != null) {
            if ((s.toUpperCase()).contains(temp)) {
                return temp;
            }
        }
        return null;
    }
}