import java.util.*;

public class SBox
{
	public static String encrypt(String input, Map<Character,Character> key)
	{
		StringBuilder cipher = new StringBuilder();
		for(int i=0;i<input.length();i++)
			cipher.append(key.get(input.charAt(i)));
		
		return cipher+"";
	}
	
	public static Map<Character,Character> generate_key()
	{
		char val='m';
		Map<Character,Character> key = new HashMap<Character,Character>();
		for(char ch='a';ch<='z';ch++) {
			key.put(ch,val);
			key.put((char)((int)ch-32),(char)((int)val-32));
			if(val=='z') {
				val='a';
				continue;
			}
			val++;
		}
		key.put('$','@');
		return key;
	}
	
	public static String decrypt(String cipher, Map<Character,Character> encrypt_key)
	{
		Map<Character, Character> decrypt_key = new HashMap<>();
		for(Map.Entry<Character, Character> entry : encrypt_key.entrySet())
			decrypt_key.put(entry.getValue(), entry.getKey());
			
		StringBuilder msg = new StringBuilder();
		for(int i=0;i<cipher.length();i++)
			msg.append(decrypt_key.get(cipher.charAt(i)));
		
		return msg+"";
	}
	
	public static void main(String args[])
	{
		Map<Character,Character> key = generate_key();	
		
		Scanner scan = new Scanner(System.in);
		System.out.print("Enter Message: ");
		String input = scan.nextLine().replace(" ","$");
		
		String cipher = encrypt(input,key);
		System.out.println("Encrypted Message: " + cipher);
		
		String msg = decrypt(cipher,key);
		System.out.println("Decrypted Message: " + msg.replace("$"," "));
	}
}