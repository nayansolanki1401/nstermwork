import java.util.*;
import java.io.*;
import java.net.*;

public class q5tcpserver
{
	public static void main(String args[]) throws IOException
	{
		ServerSocket ds=new ServerSocket(1234);	
			String un,p,eun,ep;
			Socket sk=ds.accept();
			BufferedReader br=new BufferedReader(new InputStreamReader(sk.getInputStream()));
			eun=br.readLine();
			ep=br.readLine();
			un=decrypt(eun,5);
			p=decrypt(ep,5);
			DataOutputStream dos=new DataOutputStream(sk.getOutputStream());
			if(un.equals("faizan7867") && p.equals("123456"))
			{
				dos.writeBytes("Successfully logged in!\n");
				Date d=new Date();
				dos.writeBytes(d.toString()+"\n");
			}
			else
			{
				dos.writeBytes("Invalid Login details!\n");
			}	
	}
	public static String decrypt(String s, int k)
	{
		StringBuilder sb=new StringBuilder();
		char c;
		for(int i=0; i<s.length(); i++)
		{
			if((s.charAt(i)>='a' && s.charAt(i)<='z') || (s.charAt(i)>='A' && s.charAt(i)<='Z'))
			{
				if(s.charAt(i)>=(122-(k-1)))
				{
					c=(char)(s.charAt(i)-(26-k));
					sb.append(c);
					continue;					
				}
				else if(s.charAt(i)>=(90-(k-1)) && s.charAt(i)<=90)
				{
					c=(char)(s.charAt(i)-(26-k));
					sb.append(c);
					continue;
				}
				c=(char)(s.charAt(i)+k);
				sb.append(c);
				continue;
			}
			else if(s.charAt(i)>='0' && s.charAt(i)<='9')
			{
				if(s.charAt(i)>=57-(k-1))
				{
					c=(char)(s.charAt(i)-(10-k));
					sb.append(c);
					continue;					
				}
				c=(char)(s.charAt(i)+k);
				sb.append(c);
				continue;
			}
			sb.append(s.charAt(i));
		}
		return sb.toString();
	}
}
